// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.

#define JCY
#ifdef JCY

#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define NBUCKETS 13

struct {
  struct spinlock lock[NBUCKETS];
  struct buf buf[NBUF];
  struct buf hashbucket[NBUCKETS];
  int theif[NBUCKETS];
} bcache;


inline int bhash(int x) {
  return x * 7 % NBUCKETS;
}


void
binit(void)
{
  struct buf *b;

  for (int i = 0; i < NBUCKETS; ++i) {
    initlock(&bcache.lock[i], "bcache");
    bcache.hashbucket[i].prev = &bcache.hashbucket[i];
    bcache.hashbucket[i].next = &bcache.hashbucket[i];
    bcache.theif[i] = 0;
  }

  int cnt = 0;

  // Create linked list of buffers
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    int bucket_id = bhash(cnt++);
    b->next = bcache.hashbucket[bucket_id].next;
    b->prev = &bcache.hashbucket[bucket_id];
    initsleeplock(&b->lock, "buffer");
    bcache.hashbucket[bucket_id].next->prev = b;
    bcache.hashbucket[bucket_id].next = b;
  }
}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  int bk_id = bhash(blockno);
  acquire(&bcache.lock[bk_id]);

  // Is the block already cached?
  for(b = bcache.hashbucket[bk_id].next; b != &bcache.hashbucket[bk_id]; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      b->refcnt++;
      release(&bcache.lock[bk_id]);
      acquiresleep(&b->lock);
      return b;
    }
  }

  // Not cached.
  // Recycle the least recently used (LRU) unused buffer.
  for(b = bcache.hashbucket[bk_id].prev; b != &bcache.hashbucket[bk_id]; b = b->prev){
    if(b->refcnt == 0) {
      b->dev = dev;
      b->blockno = blockno;
      b->valid = 0;
      b->refcnt = 1;
      release(&bcache.lock[bk_id]);
      acquiresleep(&b->lock);
      return b;
    }
  }

  bcache.theif[bk_id] = 1;

  // Not unused buffer
  // steal from other buckets
    for (int i = 0; i < NBUCKETS; ++i) {
    if (bcache.theif[i])
      continue;
    acquire(&bcache.lock[i]);
    for (b = bcache.hashbucket[i].prev; b != &bcache.hashbucket[i]; b = b->prev) {
      if (b->refcnt == 0) {
        // 从该桶中移除该块
        b->next->prev = b->prev;
        b->prev->next = b->next;
        release(&bcache.lock[i]);

        bcache.theif[bk_id] = 0;

        // 设置块的信息
        b->dev = dev;
        b->blockno = blockno;
        b->valid = 0;
        b->refcnt = 1;

        // 加入另外木桶
        b->next = bcache.hashbucket[bk_id].next;
        b->prev = &bcache.hashbucket[bk_id];
        bcache.hashbucket[bk_id].next->prev = b;
        bcache.hashbucket[bk_id].next = b;

        // avoid the other process visit bk_id
        release(&bcache.lock[bk_id]);
        acquiresleep(&b->lock);
        return b;
      }
    }
    release(&bcache.lock[i]);
  }
  panic("bget: no buffers");
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  int bk_id = bhash(b->blockno);
  acquire(&bcache.lock[bk_id]);
  b->refcnt--;
  if (b->refcnt == 0) {
    // no one is waiting for it.
    b->next->prev = b->prev;
    b->prev->next = b->next;
    b->next = bcache.hashbucket[bk_id].next;
    b->prev = &bcache.hashbucket[bk_id];
    bcache.hashbucket[bk_id].next->prev = b;
    bcache.hashbucket[bk_id].next = b;
  }
  
  release(&bcache.lock[bk_id]);
}

void
bpin(struct buf *b) {
  int bk_id = bhash(b->blockno);
  acquire(&bcache.lock[bk_id]);
  b->refcnt++;
  release(&bcache.lock[bk_id]);
}

void
bunpin(struct buf *b) {
  int bk_id = bhash(b->blockno);
  acquire(&bcache.lock[bk_id]);
  b->refcnt--;
  release(&bcache.lock[bk_id]);
}

#endif